from __future__ import annotations

import os
from typing import Any

from dotenv import load_dotenv
from loguru import logger
from supabase import Client, create_client

from schemas.garcom_output import GarcomAgentOutput


class StatusPedidoService:
    """
    Servico de persistencia do status de pedido no Supabase.

    Tabela alvo:
    - public.status_pedido
    """

    def __init__(self, supabase: Client | None = None) -> None:
        load_dotenv(dotenv_path=".env")
        if supabase is None:
            url = os.getenv("SUPABASE_URL")
            key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
            if not url or not key:
                raise ValueError("SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY nao configurados.")
            supabase = create_client(url, key)
        self.supabase = supabase

    def build_status_payload(
        self,
        agent_output: GarcomAgentOutput,
        estado_sessao: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Monta payload para `status_pedido` a partir do output do AGENTE_GARCOM.

        `estado_sessao` (Redis) e opcional e usado apenas para complementar
        contexto minimo quando o agente ainda nao conseguiu marcar campos.
        """
        redis_state = estado_sessao or {}
        produto_por_redis = bool(redis_state.get("ultimo_item_escolhido"))

        observacoes: list[str] = []
        if agent_output.observacao:
            observacoes.append(agent_output.observacao)
        ts = redis_state.get("timestamp_ultima_interacao")
        if ts:
            observacoes.append(f"ts={ts}")

        observacao_final = "; ".join(observacoes) if observacoes else None

        return {
            "sessionid": agent_output.sessionid,
            "produto_escolhido": bool(agent_output.produto_escolhido or produto_por_redis),
            "quantidade_produto": bool(agent_output.quantidade_produto),
            "bebida": bool(agent_output.bebida),
            "tipo_complemento": bool(agent_output.tipo_complemento),
            "complemento": bool(agent_output.complemento),
            "quantidade_complemento": bool(agent_output.quantidade_complemento),
            "observacao": observacao_final,
        }

    def upsert_status_pedido(self, payload: dict[str, Any]) -> dict[str, Any]:
        """
        Executa upsert na tabela `status_pedido` usando `sessionid` como conflito.
        """
        try:
            response = (
                self.supabase.table("status_pedido")
                .upsert(payload, on_conflict="sessionid")
                .execute()
            )
            rows = response.data or []
            return rows[0] if rows else payload
        except Exception as exc:
            logger.exception(
                "status_pedido.upsert_failed sessionid={} error={}",
                payload.get("sessionid"),
                str(exc),
            )
            raise

    def upsert_from_agent_output(
        self,
        agent_output: GarcomAgentOutput,
        estado_sessao: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Fluxo completo:
        1) monta payload de status;
        2) executa upsert no Supabase.
        """
        payload = self.build_status_payload(agent_output=agent_output, estado_sessao=estado_sessao)
        return self.upsert_status_pedido(payload)
