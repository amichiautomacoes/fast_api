from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from dotenv import load_dotenv
from openai import OpenAI
from supabase import Client, create_client


DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"
DEFAULT_MIN_SIMILARITY = 0.75
DEFAULT_MATCH_COUNT = 3
DEFAULT_CANDIDATE_COUNT = 20


@dataclass
class IntentVectorResult:
    intent: str
    similarity: float
    source: str
    raw: dict[str, Any]


class VectorSearchService:
    def __init__(
        self,
        supabase: Client | None = None,
        openai_client: OpenAI | None = None,
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
        min_similarity: float = DEFAULT_MIN_SIMILARITY,
        match_count: int = DEFAULT_MATCH_COUNT,
        candidate_count: int = DEFAULT_CANDIDATE_COUNT,
    ) -> None:
        load_dotenv(dotenv_path=".env")
        self.embedding_model = embedding_model
        self.min_similarity = min_similarity
        self.match_count = match_count
        self.candidate_count = candidate_count

        if supabase is None:
            url = os.getenv("SUPABASE_URL")
            key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
            if not url or not key:
                raise ValueError("SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY nao configurados.")
            supabase = create_client(url, key)
        self.supabase = supabase

        if openai_client is None:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY nao configurada.")
            openai_client = OpenAI(api_key=api_key)
        self.openai = openai_client

    def classify_intent_with_fallback(self, text: str) -> IntentVectorResult:
        embedding = self._create_embedding(text=text)

        # Fluxo principal: classificador vetorial
        try:
            response = self.supabase.rpc("rpc_classificar_intencao", self._build_primary_rpc_args(embedding)).execute()
            rows = response.data or []
            if rows:
                return self._parse_row(rows[0], default_source="rpc_classificar_intencao")
        except Exception:
            # Compatibilidade com versao antiga da RPC (candidate_count).
            try:
                response = self.supabase.rpc(
                    "rpc_classificar_intencao",
                    {
                        "query_embedding": embedding,
                        "match_count": self.match_count,
                        "candidate_count": self.candidate_count,
                    },
                ).execute()
                rows = response.data or []
                if rows:
                    return self._parse_row(rows[0], default_source="rpc_classificar_intencao")
            except Exception:
                # Em erro da RPC principal, tenta fallback controlado.
                pass

        # Fallback: funcao dedicada de fallback de intencao.
        try:
            fallback = self.supabase.rpc("rpc_fall_back_intencao", {}).execute()
            rows = fallback.data or []
            if rows:
                return self._parse_row(rows[0], default_source="rpc_fall_back_intencao")
        except Exception:
            pass

        # Fallback final local para garantir retorno consistente.
        return IntentVectorResult(
            intent="INTENCAO_NAO_CLASSIFICADA",
            similarity=0.0,
            source="local_fallback",
            raw={"content": "INTENCAO_NAO_CLASSIFICADA", "similarity": 0.0, "metadata": {"source": "local_fallback"}},
        )

    def _create_embedding(self, text: str) -> str:
        response = self.openai.embeddings.create(model=self.embedding_model, input=text)
        vector = response.data[0].embedding
        return "[" + ",".join(str(v) for v in vector) + "]"

    def _build_primary_rpc_args(self, embedding: str) -> dict[str, Any]:
        return {
            "query_embedding": embedding,
            "match_count": self.match_count,
            "min_similarity": self.min_similarity,
        }

    @staticmethod
    def _parse_row(row: dict[str, Any], default_source: str) -> IntentVectorResult:
        metadata = row.get("metadata") or {}
        source = metadata.get("source") or default_source
        intent = metadata.get("categoria") or row.get("content") or "INTENCAO_NAO_CLASSIFICADA"
        similarity = float(row.get("similarity") or 0.0)
        return IntentVectorResult(intent=intent, similarity=similarity, source=source, raw=row)
