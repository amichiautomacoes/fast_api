from __future__ import annotations

import os
from typing import Any

from dotenv import load_dotenv
from loguru import logger
from openai import OpenAI
from supabase import Client, create_client

DEFAULT_FALLBACK_MIN_SCORE = 0.3


class GarcomToolsService:
    def __init__(self, supabase: Client | None = None, openai_client: OpenAI | None = None) -> None:
        load_dotenv(dotenv_path=".env")
        if supabase is None:
            url = os.getenv("SUPABASE_URL")
            key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
            if not url or not key:
                raise ValueError("SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY nao configurados.")
            supabase = create_client(url, key)
        self.supabase = supabase

        if openai_client is None:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY nao configurada.")
            openai_client = OpenAI(api_key=api_key)
        self.openai = openai_client

    def buscar_opcionais_por_codigo(self, codigo_saipos: str) -> dict[str, Any]:
        try:
            response = self.supabase.rpc(
                "rpc_buscar_opcionais_por_codigo",
                {"p_codigo_saipos": codigo_saipos},
            ).execute()
            data = response.data
            if data:
                return {"source": "rpc_buscar_opcionais_por_codigo", "data": data}
        except Exception as exc:
            logger.warning(
                "garcom_tools.buscar_opcionais_rpc_failed codigo_saipos={} error={}",
                codigo_saipos,
                str(exc),
            )

        # Fallback tecnico para manter agente operacional enquanto a RPC estiver quebrada.
        fallback = self._fallback_opcionais_por_codigo(codigo_saipos)
        return {"source": "fallback_opcionais", "data": fallback}

    def buscar_pizza_por_codigo(self, codigo_saipos: str) -> dict[str, Any] | None:
        try:
            response = self.supabase.rpc(
                "rpc_buscar_pizza_por_codigo",
                {"p_codigo_saipos": codigo_saipos},
            ).execute()
            return response.data
        except Exception as exc:
            logger.exception(
                "garcom_tools.buscar_pizza_failed codigo_saipos={} error={}",
                codigo_saipos,
                str(exc),
            )
            return None

    def buscar_preco_por_codigo(self, codigo_saipos: str) -> list[dict[str, Any]]:
        try:
            response = self.supabase.rpc(
                "rpc_buscar_preco_por_codigo",
                {"p_codigo_saipos": codigo_saipos},
            ).execute()
            return response.data or []
        except Exception as exc:
            logger.exception(
                "garcom_tools.buscar_preco_failed codigo_saipos={} error={}",
                codigo_saipos,
                str(exc),
            )
            return []

    def buscar_bebida_por_codigo(self, codigo_saipos: str) -> dict[str, Any] | None:
        # Fluxo principal: RPC dedicada (quando existir no banco).
        try:
            response = self.supabase.rpc(
                "rpc_buscar_bebida_por_codigo",
                {"p_codigo_saipos": codigo_saipos},
            ).execute()
            data = response.data
            if isinstance(data, list):
                return data[0] if data else None
            return data
        except Exception as exc:
            logger.warning(
                "garcom_tools.buscar_bebida_rpc_failed codigo_saipos={} error={}",
                codigo_saipos,
                str(exc),
            )

        # Fallback tecnico: consulta direta na tabela bebida.
        try:
            rows = (
                self.supabase.table("bebida")
                .select("codigo_saipos,produto,categoria,preco,bebida_adicional")
                .eq("codigo_saipos", codigo_saipos)
                .limit(1)
                .execute()
                .data
                or []
            )
            return rows[0] if rows else None
        except Exception as exc:
            logger.exception(
                "garcom_tools.buscar_bebida_fallback_failed codigo_saipos={} error={}",
                codigo_saipos,
                str(exc),
            )
            return None

    def calcular_total_por_itens_json(self, itens: list[dict[str, Any]]) -> dict[str, Any]:
        try:
            response = self.supabase.rpc(
                "rpc_calcular_total_por_itens_json",
                {"itens": itens},
            ).execute()
            return response.data or {"itens": [], "total_geral": 0}
        except Exception as exc:
            logger.exception(
                "garcom_tools.calcular_total_failed itens_count={} error={}",
                len(itens),
                str(exc),
            )
            return {"itens": [], "total_geral": 0}

    def buscar_produtos(self, texto: str, match_count: int = 2, match_threshold: float = 0.5) -> list[dict[str, Any]]:
        query_embedding = self._create_embedding(texto)
        try:
            response = self.supabase.rpc(
                "rpc_buscar_produtos",
                {
                    "query_embedding": query_embedding,
                    "match_count": match_count,
                    "match_threshold": match_threshold,
                },
            ).execute()
            rows = response.data or []
            return self._sanitize_produto_rows(rows, score_key="score_final", min_score=match_threshold)
        except Exception as exc:
            logger.exception(
                "garcom_tools.buscar_produtos_failed texto={} match_count={} match_threshold={} error={}",
                texto,
                match_count,
                match_threshold,
                str(exc),
            )
            return []

    def fallback_buscar_produto(
        self,
        texto: str,
        match_count: int = 2,
        min_score: float = DEFAULT_FALLBACK_MIN_SCORE,
    ) -> list[dict[str, Any]]:
        effective_min_score = max(min_score, DEFAULT_FALLBACK_MIN_SCORE)
        try:
            response = self.supabase.rpc(
                "rpc_fallback_buscar_produto",
                {"p_texto": texto, "p_match_count": match_count},
            ).execute()
            rows = response.data or []
            return self._sanitize_produto_rows(rows, score_key="score", min_score=effective_min_score)
        except Exception as exc:
            logger.exception(
                "garcom_tools.fallback_buscar_produto_failed texto={} match_count={} min_score={} error={}",
                texto,
                match_count,
                effective_min_score,
                str(exc),
            )
            return []

    def _fallback_opcionais_por_codigo(self, codigo_saipos: str) -> list[dict[str, Any]]:
        # 1) Tenta tabela pizza (mais detalhada para opcionais/borda/sabor).
        try:
            pizza_rows = (
                self.supabase.table("pizza")
                .select("codigo_saipos,produto,complemento,tipo_complemento,quantidade_produto,preco")
                .eq("codigo_saipos", codigo_saipos)
                .limit(10)
                .execute()
                .data
                or []
            )
            if pizza_rows:
                return pizza_rows
        except Exception as exc:
            logger.warning(
                "garcom_tools.fallback_opcionais_pizza_failed codigo_saipos={} error={}",
                codigo_saipos,
                str(exc),
            )

        # 2) Tenta estrutura geral do tool_cardapio.
        try:
            cardapio_rows = (
                self.supabase.table("tool_cardapio")
                .select("codigo_saipos,produto,complemento,tipo_complemento,quantidade_complemento,quantidade_produto,preco")
                .eq("codigo_saipos", codigo_saipos)
                .limit(10)
                .execute()
                .data
                or []
            )
            return cardapio_rows
        except Exception as exc:
            logger.warning(
                "garcom_tools.fallback_opcionais_cardapio_failed codigo_saipos={} error={}",
                codigo_saipos,
                str(exc),
            )
            return []

    def _create_embedding(self, text: str) -> str:
        response = self.openai.embeddings.create(model="text-embedding-3-small", input=text)
        vector = response.data[0].embedding
        return "[" + ",".join(str(v) for v in vector) + "]"

    @staticmethod
    def _sanitize_produto_rows(rows: list[dict[str, Any]], score_key: str, min_score: float) -> list[dict[str, Any]]:
        sanitized: list[dict[str, Any]] = []
        for row in rows:
            produto = row.get("produto")
            score = row.get(score_key)
            if not produto:
                continue
            if score is None:
                continue
            score_float = float(score)
            if score_float < min_score:
                continue
            cleaned = dict(row)
            cleaned.pop("eh_meio_a_meio", None)
            sanitized.append(cleaned)
        return sanitized
