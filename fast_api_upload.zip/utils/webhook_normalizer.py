from __future__ import annotations

from typing import Any

from schemas.intent_input import IntentAgentInput


DEFAULT_REDIS_STATE: dict[str, Any] = {
    "etapa_atual": "SAUDACAO",
    "bebida_escolhida": None,
    "pedido_finalizado": False,
}


def _safe_get(data: dict[str, Any], path: list[str]) -> Any:
    current: Any = data
    for key in path:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def normalize_webhook_payload(
    payload: dict[str, Any] | list[dict[str, Any]],
    redis_state: dict[str, Any] | None = None,
    previous_messages: list[str] | None = None,
) -> IntentAgentInput:
    """
    Normalize raw n8n/Chatwoot webhook payload into the Agent 4 input contract.

    Supports both:
    - n8n execution format: [{ "body": {...}, ... }]
    - direct webhook body: { ... }
    """
    raw_item: dict[str, Any]
    if isinstance(payload, list):
        raw_item = payload[0] if payload else {}
    else:
        raw_item = payload

    body = raw_item.get("body", raw_item)

    sessionid = _safe_get(body, ["conversation", "contact_inbox", "source_id"])
    messageid = body.get("id")
    mensagem_atual = body.get("content")
    telefone = _safe_get(body, ["conversation", "meta", "sender", "phone_number"])
    nome = _safe_get(body, ["conversation", "meta", "sender", "name"])

    normalized: dict[str, Any] = {
        "sessionid": str(sessionid) if sessionid is not None else "",
        "messageid": str(messageid) if messageid is not None else "",
        "mensagem_atual": str(mensagem_atual) if mensagem_atual is not None else "",
        "telefone": str(telefone) if telefone else None,
        "nome": str(nome) if nome else None,
        "historico_ultimas_mensagens": (previous_messages or [])[:2],
        "estado_conversa": redis_state or DEFAULT_REDIS_STATE,
        "missing_fields": [],
    }

    if not normalized["sessionid"]:
        normalized["missing_fields"].append("sessionid")
    if not normalized["messageid"]:
        normalized["missing_fields"].append("messageid")
    if not normalized["mensagem_atual"]:
        normalized["missing_fields"].append("mensagem_atual")
    if not normalized["telefone"]:
        normalized["missing_fields"].append("telefone")
    if not normalized["nome"]:
        normalized["missing_fields"].append("nome")

    return IntentAgentInput.model_validate(normalized)
