from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class StatusPedidoInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sessionid: str = Field(min_length=1)
    produto_escolhido: bool = False
    quantidade_produto: bool = False
    bebida: bool = False
    tipo_complemento: bool = False
    complemento: bool = False
    quantidade_complemento: bool = False
    envio_pdf: bool = False
    observacao: str | None = None


class ComplementoPedidoInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tipo_complemento: str | None = None
    complemento: str | None = None
    quantidade: float | None = None
    obrigatorio: bool = False


class ItemPedidoInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    codigo_saipos: str | None = None
    quantidade: float | None = None
    bebida: str | None = None
    complementos: list[ComplementoPedidoInput] = Field(default_factory=list)
    observacao: str | None = None
    complemento_obrigatorio: bool = False


class FinalizadorAgentInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sessionid: str = Field(min_length=1)
    messageid: str = Field(min_length=1)
    status_pedido: StatusPedidoInput
    estado_sessao: dict = Field(default_factory=dict)
    itens_pedido: list[ItemPedidoInput] = Field(default_factory=list)
    origem: str = "whatsapp"
    observacao_geral: str | None = None
