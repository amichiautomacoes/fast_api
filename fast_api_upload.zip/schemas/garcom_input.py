from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

EstadoClassificado = Literal[
    "SAUDACAO",
    "CARDAPIO_ENVIADO",
    "OPCOES_SUGERIDAS",
    "MONTANDO_PEDIDO",
    "APOIO_CLIENTE",
    "FINALIZAR_PEDIDO",
]

AgenteResponsavel = Literal["AGENTE_INTENCAO", "AGENTE_GARCOM"]

EtapaSessao = Literal[
    "SAUDACAO",
    "ESCOLHA_PRODUTO",
    "ESCOLHA_SABOR",
    "COMPLEMENTOS",
    "BEBIDA",
    "CONFIRMACAO",
    "FINALIZADO",
]


class ContextoSessao(BaseModel):
    model_config = ConfigDict(extra="forbid")

    etapa_atual: EtapaSessao
    produto_em_andamento: str = Field(min_length=1)
    opcoes_ativas: list[str] = Field(default_factory=list)
    ofereceu_complemento: bool
    ofereceu_bebida: bool


class MemoriaGarcom(BaseModel):
    model_config = ConfigDict(extra="forbid")

    contexto_sessao: ContextoSessao


class ProdutoSugerido(BaseModel):
    model_config = ConfigDict(extra="forbid")

    posicao: int = Field(ge=1)
    codigo_saipos: str = Field(min_length=1)
    produto_json: dict


class GarcomAgentInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sessionid: str = Field(min_length=1)
    messageid: str = Field(min_length=1)
    estado_classificado: EstadoClassificado
    mensagem_cliente: str = Field(min_length=1)
    agente_responsavel: AgenteResponsavel
    memoria_redis: MemoriaGarcom
    produtos_sugeridos: list[ProdutoSugerido] = Field(default_factory=list, max_length=2)
