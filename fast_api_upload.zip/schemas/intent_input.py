from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

ConversationStep = Literal[
    "SAUDACAO",
    "CARDAPIO_ENVIADO",
    "OPCOES_SUGERIDAS",
    "MONTANDO_PEDIDO",
    "APOIO_CLIENTE",
    "FINALIZAR_PEDIDO",
]


class ConversationState(BaseModel):
    model_config = ConfigDict(extra="forbid")

    etapa_atual: ConversationStep
    bebida_escolhida: str | None = None
    pedido_finalizado: bool = False


class IntentAgentInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sessionid: str = Field(min_length=1)
    messageid: str = Field(min_length=1)
    mensagem_atual: str = Field(min_length=1)
    telefone: str | None = None
    nome: str | None = None
    historico_ultimas_mensagens: list[str] = Field(default_factory=list, max_length=2)
    estado_conversa: ConversationState
    missing_fields: list[str] = Field(default_factory=list)
