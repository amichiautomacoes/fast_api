from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class FinalizadorAgentOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sessionid: str = Field(min_length=1)
    status: str = Field(min_length=1)
    pedido_valido: bool
    faltando: list[str] = Field(default_factory=list)
    motivo: str | None = None
    hash_pedido: str | None = None
    payload_pdv: dict[str, Any] | None = None
