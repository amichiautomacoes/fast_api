from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from schemas.intent_input import ConversationStep

ResponsibleAgent = Literal["AGENTE_GARCOM"]


class IntentAgentOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sessionid: str = Field(min_length=1)
    messageid: str = Field(min_length=1)
    estado_classificado: ConversationStep
    agente_responsavel: ResponsibleAgent
    confidence: float = Field(ge=0.0, le=1.0)
    justificativa: str = Field(min_length=1)
