from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class GarcomAgentOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sessionid: str = Field(min_length=1)
    messageid: str = Field(min_length=1)
    resposta_mensagem_cliente: str = Field(min_length=1)

    produto_escolhido: bool = False
    quantidade_produto: bool = False
    bebida: bool = False
    tipo_complemento: bool = False
    complemento: bool = False
    quantidade_complemento: bool = False
    observacao: str | None = None
