from __future__ import annotations

from typing import Final

from services.vector_search_service import VectorSearchService
from schemas.intent_input import IntentAgentInput
from schemas.intent_output import IntentAgentOutput

DEFAULT_NEXT_AGENT: Final[str] = "AGENTE_GARCOM"

LOCAL_CONFIDENCE_THRESHOLD: Final[float] = 0.75
_VECTOR_SERVICE: VectorSearchService | None = None


def _contains_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


def _get_vector_service() -> VectorSearchService:
    global _VECTOR_SERVICE
    if _VECTOR_SERVICE is None:
        _VECTOR_SERVICE = VectorSearchService()
    return _VECTOR_SERVICE


def _is_ambiguous(current: str) -> bool:
    short_ambiguous_messages = {"ok", "blz", "isso", "pode", "qualquer", "tanto faz", "sei la"}
    if current in short_ambiguous_messages:
        return True
    if len(current.split()) <= 2 and current.endswith("?"):
        return True

    hits = 0
    if _contains_any(current, ("oi", "ola", "bom dia", "boa tarde", "boa noite")):
        hits += 1
    if _contains_any(current, ("cardapio", "menu", "opcoes", "quais sabores", "o que tem", "quais opcoes")):
        hits += 1
    if _contains_any(current, ("sugere", "recomenda", "indicacao", "mais pedido", "popular")):
        hits += 1
    if _contains_any(current, ("cancelar", "atendente", "suporte", "ajuda", "problema", "erro")):
        hits += 1
    if _contains_any(current, ("finalizar", "confirmar pedido", "fechar pedido", "pode enviar", "concluir")):
        hits += 1
    return hits >= 2


def _classify_local(current: str, full_context: str) -> tuple[str, float, str]:
    if _contains_any(
        current,
        ("finalizar", "confirmar pedido", "fechar pedido", "pode enviar", "concluir", "isso mesmo"),
    ):
        return "FINALIZAR_PEDIDO", 0.9, "Mensagem atual indica confirmacao/finalizacao do pedido."
    if _contains_any(current, ("cancelar", "atendente", "suporte", "ajuda", "problema", "erro")):
        return "APOIO_CLIENTE", 0.9, "Mensagem atual indica necessidade de apoio humano/suporte."
    if _contains_any(
        current,
        ("cardapio", "menu", "opcoes", "quais sabores", "o que tem", "quais opcoes"),
    ):
        return "CARDAPIO_ENVIADO", 0.85, "Mensagem atual pede visualizacao de cardapio/opcoes."
    if _contains_any(
        current,
        ("sugere", "recomenda", "indicacao", "mais pedido", "popular"),
    ):
        return "OPCOES_SUGERIDAS", 0.8, "Mensagem atual solicita sugestoes/recomendacoes."
    if _contains_any(current, ("oi", "ola", "bom dia", "boa tarde", "boa noite")) and len(current) <= 20:
        return "SAUDACAO", 0.85, "Mensagem curta com padrao de saudacao."
    if _contains_any(full_context, ("menu", "cardapio", "opcoes", "sugere", "recomenda")):
        return "CARDAPIO_ENVIADO", 0.75, "Historico recente sugere contexto de cardapio/opcoes."
    return "MONTANDO_PEDIDO", 0.7, "Mensagem tratada como continuidade da montagem do pedido."


def _normalize_vector_state(value: str) -> str | None:
    normalized = value.strip().upper()
    if normalized in {
        "SAUDACAO",
        "CARDAPIO_ENVIADO",
        "OPCOES_SUGERIDAS",
        "MONTANDO_PEDIDO",
        "APOIO_CLIENTE",
        "FINALIZAR_PEDIDO",
    }:
        return normalized
    aliases = {
        "INTENCAO_NAO_CLASSIFICADA": None,
        "CARDAPIO": "CARDAPIO_ENVIADO",
        "FINALIZADO": "FINALIZAR_PEDIDO",
    }
    return aliases.get(normalized)


def classify_conversation_state(data: IntentAgentInput) -> IntentAgentOutput:
    history = " ".join(data.historico_ultimas_mensagens).strip().lower()
    current = data.mensagem_atual.strip().lower()
    full_context = f"{history} {current}".strip()

    estado, confidence, justificativa = _classify_local(current=current, full_context=full_context)
    ambiguous = _is_ambiguous(current)

    if confidence < LOCAL_CONFIDENCE_THRESHOLD or ambiguous:
        try:
            vector_result = _get_vector_service().classify_intent_with_fallback(full_context or current)
            vector_state = _normalize_vector_state(vector_result.intent)
            if vector_state:
                estado = vector_state
                confidence = max(confidence, vector_result.similarity)
                justificativa = (
                    "Classificacao vetorial aplicada por baixa confianca/ambiguidade. "
                    f"source={vector_result.source}"
                )
        except Exception:
            # Se a consulta vetorial falhar, preserva resultado local.
            pass

    return IntentAgentOutput(
        sessionid=data.sessionid,
        messageid=data.messageid,
        estado_classificado=estado,
        agente_responsavel=DEFAULT_NEXT_AGENT,
        confidence=confidence,
        justificativa=justificativa,
    )
