from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from schemas.finalizador_input import FinalizadorAgentInput, ItemPedidoInput
from schemas.finalizador_output import FinalizadorAgentOutput


class FinalizadorAgent:
    """
    Agente responsavel por validar se o pedido pode ser finalizado.

    Este agente nao persiste dados. Ele apenas:
    - avalia o status atual do pedido;
    - aponta pendencias;
    - monta payload padrao para envio ao PDV quando valido.
    """

    def process(self, data: FinalizadorAgentInput) -> FinalizadorAgentOutput:
        return self.finalizar_pedido(
            status_pedido=data.status_pedido.model_dump(),
            pedido={
                "sessionid": data.sessionid,
                "messageid": data.messageid,
                "origem": data.origem,
                "itens": [item.model_dump() for item in data.itens_pedido],
                "observacao_geral": data.observacao_geral or data.status_pedido.observacao,
            },
        )

    def detectar_pendencias(self, status_pedido: dict[str, Any], pedido: dict[str, Any]) -> list[str]:
        pendencias: list[str] = []
        itens = pedido.get("itens", [])
        valid_items = [item for item in itens if self._is_item_valido(item)]
        has_any_item = len(itens) > 0

        if not has_any_item:
            pendencias.append("definir produto")
            pendencias.append("item_principal")

        if bool(status_pedido.get("produto_escolhido", False)) and not valid_items:
            pendencias.append("item_principal")

        if bool(status_pedido.get("produto_escolhido", False)) and not has_any_item:
            pendencias.append("produto_escolhido_sem_item")

        if any(not self._has_codigo_valido(item) for item in itens):
            pendencias.append("codigo_produto")

        if any(not self._has_quantidade_valida(item) for item in itens):
            pendencias.append("quantidade_produto")

        if bool(status_pedido.get("quantidade_produto", False)) and any(
            not self._has_quantidade_valida(item) for item in itens
        ):
            pendencias.append("quantidade_produto")

        has_bebida = any(bool(str(item.get("bebida") or "").strip()) for item in itens)
        has_tipo_complemento = any(
            bool(str(comp.get("tipo_complemento") or "").strip())
            for item in itens
            for comp in item.get("complementos", [])
        )
        has_complemento = any(
            bool(str(comp.get("complemento") or "").strip())
            for item in itens
            for comp in item.get("complementos", [])
        )
        has_qtd_complemento = any(
            comp.get("quantidade") is not None and float(comp.get("quantidade")) > 0
            for item in itens
            for comp in item.get("complementos", [])
        )

        if bool(status_pedido.get("bebida", False)) and not has_bebida:
            pendencias.append("bebida")
        if bool(status_pedido.get("tipo_complemento", False)) and not has_tipo_complemento:
            pendencias.append("tipo_complemento")
        if bool(status_pedido.get("complemento", False)) and not has_complemento:
            pendencias.append("complemento")
        if bool(status_pedido.get("quantidade_complemento", False)) and not has_qtd_complemento:
            pendencias.append("quantidade_complemento")

        if any(bool(item.get("complemento_obrigatorio", False)) and not item.get("complementos", []) for item in itens):
            pendencias.append("complemento")

        # Remove duplicados sem perder ordem.
        dedup: list[str] = []
        seen: set[str] = set()
        for item in pendencias:
            if item in seen:
                continue
            dedup.append(item)
            seen.add(item)
        return dedup

    @staticmethod
    def _is_item_valido(item: dict[str, Any] | ItemPedidoInput) -> bool:
        return FinalizadorAgent._has_codigo_valido(item) and FinalizadorAgent._has_quantidade_valida(item)

    @staticmethod
    def _has_codigo_valido(item: dict[str, Any] | ItemPedidoInput) -> bool:
        codigo = item.codigo_saipos if isinstance(item, ItemPedidoInput) else item.get("codigo_saipos")
        return bool(str(codigo or "").strip())

    @staticmethod
    def _has_quantidade_valida(item: dict[str, Any] | ItemPedidoInput) -> bool:
        quantidade = item.quantidade if isinstance(item, ItemPedidoInput) else item.get("quantidade")
        if quantidade is None:
            return False
        try:
            return float(quantidade) > 0
        except (TypeError, ValueError):
            return False

    def validar_pedido_final(self, status_pedido: dict[str, Any], pedido: dict[str, Any]) -> dict[str, Any]:
        faltando = self.detectar_pendencias(status_pedido=status_pedido, pedido=pedido)
        return {
            "pedido_valido": len(faltando) == 0,
            "faltando": faltando,
        }

    def montar_payload_pdv(self, pedido: dict[str, Any]) -> dict[str, Any]:
        itens_payload: list[dict[str, Any]] = []
        for item in pedido.get("itens", []):
            bebida_obj = None
            bebida_valor = item.get("bebida")
            if isinstance(bebida_valor, dict):
                bebida_obj = {
                    "codigo_saipos": bebida_valor.get("codigo_saipos"),
                    "quantidade": bebida_valor.get("quantidade", 1),
                }
            elif bebida_valor:
                bebida_obj = {"codigo_saipos": str(bebida_valor), "quantidade": 1}

            itens_payload.append(
                {
                    "codigo_saipos": item.get("codigo_saipos"),
                    "quantidade": item.get("quantidade"),
                    "bebida": bebida_obj,
                    "complementos": [
                        {
                            "codigo_saipos": comp.get("codigo_saipos"),
                            "quantidade": comp.get("quantidade"),
                        }
                        for comp in item.get("complementos", [])
                    ],
                    "observacao": item.get("observacao"),
                }
            )

        return {
            "sessionid": pedido.get("sessionid"),
            "origem": pedido.get("origem", "whatsapp"),
            "itens": itens_payload,
            "observacao_geral": pedido.get("observacao_geral"),
            "resumo_pedido": self.gerar_resumo_pedido(pedido),
            "timestamp_finalizacao": datetime.now(timezone.utc).isoformat(),
        }

    def gerar_resumo_pedido(self, pedido: dict[str, Any]) -> str:
        partes: list[str] = []
        for item in pedido.get("itens", []):
            qtd = item.get("quantidade")
            nome = item.get("nome_produto") or item.get("produto") or item.get("codigo_saipos")
            obs = item.get("observacao")
            trecho = f"{qtd}x {nome}" if qtd is not None else str(nome)
            if obs:
                trecho += f" ({obs})"
            partes.append(trecho)
        return " + ".join(partes) if partes else "Pedido sem itens"

    @staticmethod
    def gerar_hash_pedido(payload: dict[str, Any]) -> str:
        canonical = json.dumps(payload, ensure_ascii=True, separators=(",", ":"), sort_keys=True)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def finalizar_pedido(self, status_pedido: dict[str, Any], pedido: dict[str, Any]) -> FinalizadorAgentOutput:
        validacao = self.validar_pedido_final(status_pedido=status_pedido, pedido=pedido)
        faltando = validacao["faltando"]
        pedido_valido = bool(validacao["pedido_valido"])

        if not pedido_valido:
            return FinalizadorAgentOutput(
                status="PENDENTE_INFORMACOES",
                pedido_valido=False,
                sessionid=str(pedido.get("sessionid") or ""),
                faltando=faltando,
                motivo="Pedido incompleto para envio ao PDV",
                hash_pedido=None,
                payload_pdv=None,
            )

        payload_pdv = self.montar_payload_pdv(pedido)
        hash_pedido = self.gerar_hash_pedido(payload_pdv)
        return FinalizadorAgentOutput(
            status="APROVADO_PARA_ENVIO",
            pedido_valido=True,
            sessionid=str(pedido.get("sessionid") or ""),
            faltando=[],
            motivo=None,
            hash_pedido=hash_pedido,
            payload_pdv=payload_pdv,
        )
