﻿from __future__ import annotations

import re
from typing import Any

from schemas.garcom_input import GarcomAgentInput
from schemas.garcom_output import GarcomAgentOutput
from services.garcom_tools_service import GarcomToolsService


class GarcomAgent:
    def __init__(self, tools: GarcomToolsService | None = None) -> None:
        self.tools = tools or GarcomToolsService()

    def process(self, data: GarcomAgentInput) -> GarcomAgentOutput:
        """
        Primeira versao do agente garcom com foco nas decisoes:
        - BUSCAR_PRODUTO
        - COLETAR_COMPLEMENTO
        - OFERECER_BEBIDA
        """
        mensagem = data.mensagem_cliente.lower()

        if self._is_total_query(mensagem):
            itens = [
                {"codigo_saipos": item.codigo_saipos, "quantidade": 1}
                for item in data.produtos_sugeridos
            ]
            total = self.calcular_total(itens)
            total_geral = total.get("total_geral")
            if total_geral is None:
                resposta = "Ainda nao consegui calcular o total do pedido."
            else:
                resposta = f"O total parcial do pedido esta em R$ {float(total_geral):.2f}."

            return GarcomAgentOutput(
                sessionid=data.sessionid,
                messageid=data.messageid,
                resposta_mensagem_cliente=resposta,
                produto_escolhido=bool(itens),
                quantidade_produto=bool(itens),
                bebida=self._has_beverage_signal(mensagem),
                observacao=f"itens={len(itens)}",
            )

        if self._is_price_query(mensagem):
            codigo = data.produtos_sugeridos[0].codigo_saipos if data.produtos_sugeridos else None
            if codigo is None:
                busca = self.buscar_produto(data.mensagem_cliente)
                opcoes_busca = busca.get("opcoes", [])
                codigo = opcoes_busca[0].get("codigo_saipos") if opcoes_busca else None

            preco = self.consultar_preco(codigo) if codigo else []
            resposta = "Encontrei o preco do item selecionado." if preco else "Nao encontrei o preco desse item agora."

            return GarcomAgentOutput(
                sessionid=data.sessionid,
                messageid=data.messageid,
                resposta_mensagem_cliente=resposta,
                produto_escolhido=bool(codigo),
                quantidade_produto=self._has_quantity_signal(mensagem),
                bebida=self._has_beverage_signal(mensagem),
                observacao=f"codigo_saipos={codigo}" if codigo else "codigo_saipos_nao_identificado",
            )

        produto_result = self.buscar_produto(data.mensagem_cliente)
        opcoes = produto_result["opcoes"]

        complementos: list[dict[str, Any]] = []
        bebidas: list[dict[str, Any]] = []

        # Para esta fase inicial, trabalha com a melhor opcao retornada.
        if opcoes:
            principal = opcoes[0]
            complementos = self.coletar_complemento(principal)
            bebidas = self.oferecer_bebida(
                produto=principal,
                pedido_produto_concluido=data.estado_classificado == "FINALIZAR_PEDIDO",
                cliente_aceitou_bebida=False,
            )

        return GarcomAgentOutput(
            sessionid=data.sessionid,
            messageid=data.messageid,
            resposta_mensagem_cliente=self._build_search_response(opcoes),
            produto_escolhido=bool(opcoes),
            quantidade_produto=self._has_quantity_signal(mensagem),
            bebida=bool(bebidas) or self._has_beverage_signal(mensagem),
            tipo_complemento=any(bool(item.get("tipo_complemento")) for item in complementos),
            complemento=bool(complementos),
            quantidade_complemento=any(
                bool(item.get("quantidade_complemento")) or bool(item.get("quantidade_produto"))
                for item in complementos
            ),
            observacao=(
                f"opcoes={len(opcoes)};complementos={len(complementos)};bebidas_sugeridas={len(bebidas)}"
            ),
        )

    @staticmethod
    def _is_price_query(mensagem: str) -> bool:
        return any(token in mensagem for token in ("preco", "valor", "quanto custa", "custa quanto"))

    @staticmethod
    def _is_total_query(mensagem: str) -> bool:
        return any(token in mensagem for token in ("total", "soma", "somar", "quanto deu", "valor total"))

    @staticmethod
    def _has_quantity_signal(mensagem: str) -> bool:
        if re.search(r"\b\d+\b", mensagem):
            return True
        return any(token in mensagem for token in ("um", "uma", "dois", "duas", "tres", "qtde", "quantidade"))

    @staticmethod
    def _has_beverage_signal(mensagem: str) -> bool:
        return any(
            token in mensagem
            for token in ("bebida", "refrigerante", "refri", "suco", "agua", "cerveja", "coca", "guarana")
        )

    @staticmethod
    def _build_search_response(opcoes: list[dict[str, Any]]) -> str:
        if not opcoes:
            return "Nao encontrei um produto claro com essa mensagem. Pode me dizer o item exato?"

        produto = opcoes[0].get("produto")
        if produto:
            return f"Encontrei {produto}. Quer confirmar esse item?"

        return "Encontrei opcoes para seu pedido. Quer confirmar a primeira opcao?"

    def buscar_produto(self, mensagem_cliente: str) -> dict[str, Any]:
        """
        Regra:
        - Busca principal por similaridade.
        - Retorna ate 2 opcoes com score >= 0.75.
        - Se top score da busca principal < 0.50 (ou sem resultado), tenta fallback.
        """
        principal_rows = self.tools.buscar_produtos(
            texto=mensagem_cliente,
            match_count=5,
            match_threshold=0.50,
        )
        top_score_principal = principal_rows[0].get("score_final", 0.0) if principal_rows else 0.0

        candidatos = [row for row in principal_rows if float(row.get("score_final", 0.0)) >= 0.75][:2]
        used_fallback = False

        if not candidatos and top_score_principal < 0.50:
            fallback_rows = self.tools.fallback_buscar_produto(
                texto=mensagem_cliente,
                match_count=5,
                min_score=0.50,
            )
            candidatos = [row for row in fallback_rows if float(row.get("score", 0.0)) >= 0.75][:2]
            used_fallback = True

        return {
            "opcoes": candidatos,
            "used_fallback": used_fallback,
            "top_score_principal": float(top_score_principal),
        }

    def coletar_complemento(self, produto: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Regra:
        - Se tem_complemento = True, buscar opcionais por codigo.
        """
        if not bool(produto.get("tem_complemento", False)):
            return []

        codigo = produto.get("codigo_saipos")
        if not codigo:
            return []

        response = self.tools.buscar_opcionais_por_codigo(str(codigo))
        data = response.get("data")
        return data if isinstance(data, list) else ([data] if data else [])

    def oferecer_bebida(
        self,
        produto: dict[str, Any],
        pedido_produto_concluido: bool,
        cliente_aceitou_bebida: bool,
    ) -> list[dict[str, Any]]:
        """
        Regra:
        - Se tem_bebida = True e o pedido do produto foi concluido, perguntar bebida.
        - Se cliente aceitar, buscar bebida por codigo_saipos.
        """
        if not bool(produto.get("tem_bebida", False)):
            return []
        if not pedido_produto_concluido:
            return []
        if not cliente_aceitou_bebida:
            return []

        codigo = produto.get("codigo_saipos")
        if not codigo:
            return []

        bebida = self.tools.buscar_bebida_por_codigo(str(codigo))
        return [bebida] if bebida else []

    def consultar_preco(self, codigo_saipos: str) -> list[dict[str, Any]]:
        """
        Regra:
        - Buscar preco do item quando o cliente perguntar valor.
        """
        return self.tools.buscar_preco_por_codigo(codigo_saipos)

    def calcular_total(self, itens: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Regra:
        - Somar os itens escolhidos por codigo_saipos.
        """
        return self.tools.calcular_total_por_itens_json(itens)
