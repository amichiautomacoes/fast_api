from __future__ import annotations

from typing import Any

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from pydantic import ValidationError

from agents.intent_agent import classify_conversation_state
from utils.webhook_normalizer import normalize_webhook_payload

app = FastAPI(
    title="Garcom Digital API",
    version="0.1.0",
    description="API base para receber webhook e normalizar/classificar a mensagem.",
)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/webhook")
async def webhook(request: Request) -> dict[str, Any]:
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Payload JSON invalido: {exc}") from exc

    if not isinstance(payload, (dict, list)):
        raise HTTPException(status_code=400, detail="Payload deve ser um objeto JSON ou lista JSON.")

    try:
        normalized = normalize_webhook_payload(payload=payload)
        intent = classify_conversation_state(normalized)
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors()) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Falha ao processar webhook: {exc}") from exc

    return {
        "status": "processed",
        "normalized": normalized.model_dump(),
        "intent": intent.model_dump(),
    }


@app.post("/webhook-test/{webhook_id}")
async def webhook_test(webhook_id: str, request: Request) -> dict[str, Any]:
    response = await webhook(request)
    response["webhook_id"] = webhook_id
    return response


def main() -> None:
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)


if __name__ == "__main__":
    main()

